<?php
  // footer.php
?>
<footer class="footer">
  <div class="bloco" style="text-align: center;">
    <h5>
      <i><u>WebMaster: PedroTeixeira - 2025</u></i>
    </h5>
    <img src="imagens/logos.png" alt="Logos" />
  </div>
</footer>
</body>
</html>
